import React from "react";

const Footer = () => {
  return (
    <div className="footer">
      <div className="copyright">
   
      </div>
    </div>
  );
};

export default Footer;
