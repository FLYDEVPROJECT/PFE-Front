import React from 'react';
import './Home.css';
import {link} from 'react-router-dom'; 
function H() {
  return (
   <>
 Je suis page d'Accueil
   </>
  );
}

export default Ho;