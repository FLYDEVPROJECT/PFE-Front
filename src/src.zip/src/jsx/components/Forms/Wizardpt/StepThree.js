import React from "react";
 
const LockScreen = ({ history }) => {
   const submitHandler = (e) => {
      e.preventDefault();
      history.push("/");
   };
   return (
      <div className="row">
      <div className="col-lg-12 mb-2">
         <div className="form-group">
         <div className="col-lg-12 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
           <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
           <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> 
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br></h1></div><br></br>
           <br></br>
           
      <div className="authincation h-100 p-meddle">
         <div className="container h-100">
            <div className="row justify-content-center h-100 align-items-center">
               <div className="col-md-8">
                  <div className="authincation-content">
                     <div className="row no-gutters">
                        <div className="col-xl-12">
                           <div className="auth-form">
                           <h6 className="text-center mb-4">
                               Etape 3/4
                              </h6>
                              <h2 className="text-center mb-4">
                              Antécédents
                              </h2><br></br> <br></br>
                              <form
                                 action=""
                                 onSubmit={(e) => submitHandler(e)}
                              >
                                <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label">  <strong>  Avez-vous des problèmes cardiaques </strong> </label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Avez-vous déjà fumé du tabac de quelque sorte?
Veuillez indiquer quel produit</strong></label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Avez-vous d’autres problèmes respiratoires? </strong> </label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Avez-vous déjà eu une maladie ou un trouble lié au sang? </strong></label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Avez-vous déjà eu des problèmes importants de mémoire ou de démence? </strong> </label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Est-ce que vous ou un membre de votre famille (lié à vous par le sang)
avez eu des problèmes graves autres que des nausées et vomissements
après avoir reçu une anesthésie générale </strong> </label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong>Avez-vous été admis(e) à l’hôpital dans le passé? </strong></label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez ( Quand? Où? Pourquoi?)"                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Etes vous concerné par des problèmes de santé mentale (ex.
, crises d’angoisse, phobie des aiguilles)?</strong></label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez ( Quand? Où? Pourquoi?)"                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"><strong> Y’a-t-il des problèmes d’allergie dans l’anamnèse personnelle ?</strong></label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez ( Quand? Où? Pourquoi?)"                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
 
                 
 
 
 
                              </form>
                              </div>
 
                        </div>
                     </div>
                  </div>
               </div>
               </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   );
};
 
export default LockScreen;
