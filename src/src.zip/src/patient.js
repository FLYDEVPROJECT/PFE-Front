import React, { Component ,Fragment} from "react";
import Switch from "react-switch";
import swal from "sweetalert";
import swalMessage from "@sweetalert/with-react";
import Multistep from "react-multistep";
import Tes from "./Tes";


class App extends Component {
  constructor() {
    super();
  
    this.state = {
      
      checked: false,
      p1: {
        visibility: "visible",
        display: "block"
      },
      p2P: {
        visibility: "hidden",
        display: "none"
      },
      p3P: {
        visibility: "hidden",
        display: "none"
      },
      p4P: {
        visibility: "hidden",
        display: "none"
      },
      p2M: {
        visibility: "hidden",
        display: "none"
      },
      p3M: {
        visibility: "hidden",
        display: "none"
      },
      p4M: {
        visibility: "hidden",
        display: "none"
      },
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(checked) {
    this.setState({ checked });
  }
  nextp2 = () => {
    if (this.state.checked == false) { // false mean patient
      //treat your object patient state 
      this.setState({ p1: { visibility: "hidden", display: "none" } })
      this.setState({ p2M: { visibility: "hidden", display: "none" } })
      this.setState({ p3P: { visibility: "hidden", display: "none" } })
      this.setState({ p4P: { visibility: "hidden", display: "none" } })
      this.setState({ p3M: { visibility: "hidden", display: "none" } })
      this.setState({ p4M: { visibility: "hidden", display: "none" } })
      this.setState({ p2P: { visibility: "visible", display: "block" } })
    } else {
      //treat your object medecin state

      this.setState({ p1: { visibility: "hidden", display: "none" } })
      this.setState({ p2P: { visibility: "hidden", display: "none" } })
      this.setState({ p3P: { visibility: "hidden", display: "none" } })
      this.setState({ p4P: { visibility: "hidden", display: "none" } })
      this.setState({ p3M: { visibility: "hidden", display: "none" } })
      this.setState({ p4M: { visibility: "hidden", display: "none" } })
      this.setState({ p2M: { visibility: "visible", display: "block" } })
    }
 
  }
  nextp3 = () => {
    if (this.state.checked == false) {
      //treat your object patient state

      this.setState({ p1: { visibility: "hidden", display: "none" } })
      this.setState({ p2M: { visibility: "hidden", display: "none" } })
      this.setState({ p2P: { visibility: "hidden", display: "none" } })
      this.setState({ p4P: { visibility: "hidden", display: "none" } })
      this.setState({ p3M: { visibility: "hidden", display: "none" } })
      this.setState({ p4M: { visibility: "hidden", display: "none" } })
      this.setState({ p3P: { visibility: "visible", display: "block" } })
    } else {
      //treat your object medecin state

      this.setState({ p1: { visibility: "hidden", display: "none" } })
      this.setState({ p2P: { visibility: "hidden", display: "none" } })
      this.setState({ p3P: { visibility: "hidden", display: "none" } })
      this.setState({ p4P: { visibility: "hidden", display: "none" } })
      this.setState({ p2M: { visibility: "hidden", display: "none" } })
      this.setState({ p4M: { visibility: "hidden", display: "none" } })
      this.setState({ p3M: { visibility: "visible", display: "block" } })
    }
   
  }
  nextp4 = () => {
    if (this.state.checked == false) {
      //treat your object patient state

      this.setState({ p1: { visibility: "hidden", display: "none" } })
      this.setState({ p2M: { visibility: "hidden", display: "none" } })
      this.setState({ p2P: { visibility: "hidden", display: "none" } })
      this.setState({ p3P: { visibility: "hidden", display: "none" } })
      this.setState({ p3M: { visibility: "hidden", display: "none" } })
      this.setState({ p4M: { visibility: "hidden", display: "none" } })
      this.setState({ p4P: { visibility: "visible", display: "block" } })
    } else {
      //treat your object medecin state

      this.setState({ p1: { visibility: "hidden", display: "none" } })
      this.setState({ p2P: { visibility: "hidden", display: "none" } })
      this.setState({ p3P: { visibility: "hidden", display: "none" } })
      this.setState({ p4P: { visibility: "hidden", display: "none" } })
      this.setState({ p2M: { visibility: "hidden", display: "none" } })
      this.setState({ p3M: { visibility: "hidden", display: "none" } })
      this.setState({ p4M: { visibility: "visible", display: "block" } })
   
    }
   
  }
 
  finish = () => {
    if (this.state.checked == false) {
      //treat your object patient state
      console.log('signin as patient')

    } else {
      //treat your object medecin state
      
      console.log('signin as medecin')


    }

  }
  finish = () => {
  }


  
  render() {
 
    const steps = [
        { name: "Etat civil du professionel de santé" , component: <Tes />  },
        { name: "Informations sur le professionel de santé", component: <test /> },
        { name: "Informations sur l'établissement" ,component: <test />},
        { name: "Sécurité" },
     ];
     const prevStyle = {
        background: "#F7FAFC",
        borderWidth: "0px",
        color: "#333333",
        borderRadius: "4px",
        fontSize: "14px",
        fontWeight: "600",
        padding: "0.55em 2em",
        border: "1px solid #EEEEEE",
        marginRight: "1rem",
     };
     const nextStyle = {
        background: "#36c95f",
        borderWidth: "0px",
        color: "#fff",
        borderRadius: "4px",
        fontSize: "14px",
        fontWeight: "600",
        padding: "0.55em 2em",
     };

     return (
        <>
        
       
          {this.state.nbpage}
          <div style={this.state.p1}>
           
    
   
         <div className="row">
        
         
         <div className="col-lg-12 mb-2">
            <div className="form-group">
            <div className="col-lg-8 mb-2">
                
                  <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
              <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> 
                  <div className="form-group"></div>
                  <div className="form-group"></div>
              <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
                  <div className="form-group"></div>
              <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
                  <div className="form-group"></div>
              <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
                  <div className="form-group"></div>
              <h1>   <div className="col-lg-8 mb-2">
                  <div className="form-group"></div>
              <h1></h1></div><br></br></h1></div><br></br>
              <br></br>
              
         <div className="authincation h-100 p-meddle">
            <div className="container h-100">
               <div className="row justify-content-center h-100 align-items-center">
                  <div className="col-md-8">
                     <div className="authincation-content">
                        <div className="row no-gutters">
                           <div className="col-xl-12">
                           <div class="container">
    <div class="row justify-content-md-center">
      <div class="col col-lg-2">
       
      </div>
      <div class="col-md-auto">
      <span  style={{'color':"#0000CD"}}>{this.state.checked == false ? "Patient" : "Professionnel de santé"}
  </span>
  <Switch onChange={this.handleChange}  checked={this.state.checked}  />
      </div>
      <div class="col col-lg-2">
      
      </div>
    </div>
    </div>
    <h6 className="text-center mb-4">
                                  Etape 1/4
                                 </h6>
                           <Fragment>
       
  
       <div className="row">
          <div className="col-xl-12 col-xxl-12">
             <div className="card">
                <div className="card-header">
                   <h4 className="card-title"></h4>
                </div>
                <div className="card-body">
                   <form
                      onSubmit={(e) => e.preventDefault()}
                      id="step-form-horizontal"
                      className="step-form-horizontal"
                   >
                      <Multistep
                         showNavigation={true}
                         steps={steps}
                         prevStyle={prevStyle}
                         nextStyle={nextStyle}
                      />
                   </form>
                </div>
             </div>
          </div>
       </div>
    </Fragment>
  
    
  
             
                              <div className="auth-form">
                              
                                 <h2 className="text-center mb-4">
                                    Etat civil 
                                 </h2>
                                 <form
                                    action=""
                                   
                                 >
                                   <div className="col-lg-12 mb-3">
                  <div className="form-group">
                  <label className="text-label">  <strong>  Nom*</strong> </label></div>
                     <input
                        type="text"
                        name="firstName"
                        className="form-control"
                        placeholder="Parsley"
                        required
                     />
                  
               </div>
            <div className="col-lg-12 mb-3">
                  <div className="form-group">
                  <label className="text-label"><strong> Prénom *</strong> </label></div>
                     <input
                        type="text"
                        name="firstName"
                        className="form-control"
                        placeholder="Parsley"
                        required
                     />    
               </div>
    
               <div className="col-lg-12 mb-3">
                  <div className="form-group">
                  <label className="text-label"><strong>Joindrez votre photo</strong></label></div>
      
    
       <input type="file"
              id="avatar" name="avatar"
              accept="image/png, image/jpeg"  className="form-control"/>
               </div>
    
    
               <div className="col-lg-12 mb-3">
                  <div className="form-group">
                  <label className="text-label"><strong>Sexe *</strong></label>
   <br></br>      
           <input type="radio" value="Male" name="gender" /> Homme         
           <input type="radio" value="Female" name="gender" /> Femme  
               </div>
               </div>
    
    
               <div className="col-lg-12 mb-3">
                  <div className="form-group">
                  <label className="text-label"><strong>Date de Naissance*</strong></label></div>
                  <input
                        type="Date"
                        className="form-control"
                        id="inputGroupPrepend2"
                        aria-describedby="inputGroupPrepend2"
                  
                        required
                     />  
               </div>
    
    
               <div className="col-lg-12 mb-3">
                  <div className="form-group">
                  <label className="text-label"><strong>Numéro de télephone</strong></label></div>
      
    
       <input
                        type="text"
                        name="phoneNumber"
                        className="form-control"
                        placeholder="(+216)"
                        required
                     />
               </div>
    
    
               <div className="col-lg-12 mb-3">
                  <div className="form-group">
                  <label className="text-label"><strong>Adresse E-mail*</strong></label></div>
      
    
               <input
                        type="email"
                        name="place"
                        className="form-control"
                        placeholder="example@gmail.com"
                        required
                     />
               </div>
    
                  <div className="form-group">
                  <div className="form-group col-md-12">
                  <label className="text-label"><strong>Ville*</strong></label>
                                                   <select
                                                     className="form-control"
                                                     id="inputState"
                                                     defaultValue="option-1"
                                                   >
                                                     <option value="option-1">Ariana</option>
                                                     <option value="option-2">Beja </option>
                                                     <option value="option-3">Ben Arous</option>
                                                     <option value="option-4">Bizerte</option>
                                         <option value="option-5">Gabes</option>
                                         <option value="option-6">Gafsa</option>
                                         <option value="option-7">Jendouba</option>
                                         <option value="option-8">Kairouan</option>
                                         <option value="option-9">Kasserine</option>
                                         <option value="option-10">kebili</option>
                                         <option value="option-11">La Manouba</option>
                                         <option value="option-12">Kef</option>
                                         <option value="option-13">Mahdia</option>
                                         <option value="option-14">Médenine</option>
                                         <option value="option-15">Monastir</option>
                                         <option value="option-16">Nabeul</option>
                                         <option value="option-17">Sfax</option>
                                         <option value="option-18">Sidi Bouzid</option>
                                         <option value="option-19">Siliana</option>
                                         <option value="option-20">Sousse</option>
                                         <option value="option-21">Tataouine</option>
                                         <option value="option-22">Tozeur</option>
                                         <option value="option-23">Tunis</option>
                                         <option value="option-24">zaghouan</option>
                                                   </select>
                                           </div>
                                 </div>
                                 
                                 
    
    
               <div className="col-lg-12 mb-3">
                  <div className="form-group">
                  <label className="text-label"><strong>Adresse *</strong></label></div>
      
    
       <input
                        type="Text"
                        name="place"
                        className="form-control"
                        required
                     />
               </div>
    
               <div className="col-lg-12 mb-3">
                  <div className="form-group">
                  <label className="text-label"><strong>Code Postal *</strong></label>
                     <input
                        type="number"
                        name="place"
                        className="form-control"
                        placeholder="3000"
                        required
                     />
               </div>
               </div>
               <div class="row justify-content-around">
      <div class="col-4">
  </div>
      <div class="col-3">
      <button className="btn btn-primary btn-block"  onClick={this.nextp2}>suivant</button>   
      </div>
    </div>
               <div class="row">
               <div class="col-sm">
              
  </div></div>
               
                                 </form>
                                 </div>
    
                           </div>
                        </div>
                     </div>
                  </div>
                  </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      
   
    
  
             
            
          </div>

        <div style={this.state.p2P}>
        <div className="row">
      <div className="col-lg-12 mb-2">
         <div className="form-group">
         <div className="col-lg-12 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
           <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> 
             
             
               <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br></h1></div><br></br>
           <br></br>
           
      <div className="authincation h-100 p-meddle">
         <div className="container h-100">
            <div className="row justify-content-center h-100 align-items-center">
               <div className="col-md-8">
                  <div className="authincation-content">
                     <div className="row no-gutters">
                        <div className="col-xl-12">
                           <div className="auth-form">
                           <h6 className="text-center mb-4">
                               Etape 2/4
                              </h6>
                              <h2 className="text-center mb-4">
                              Information sur le patient
                              </h2><br></br> <br></br>
                              <form
                                 action=""
                               
                              >
                                <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Code Sécurité Sociale ( CSS)*</strong></label>
                  <input
                     type="Password"
                     name="place"
                     className="form-control"
                     placeholder="*********"
                     required
                  />
                  </div>
               
            </div>
         <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Nombre d'enfants</strong></label>
                  <input
                     type="Number"
                     className="form-control"
                     id="emial1"
                     placeholder="0"
                     required
                  />
                  </div>
            </div>
 
            <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Profession / Scolarité*</strong></label>
                                    <select
                                      className="form-control"
                                      id="inputState"
                                      defaultValue="option-1"
                                    >
                                      <option value="option-1">Profession</option>
                                      <option value="option-2">Education  </option>
                                      <option value="option-3">Autre</option>
                                     
                        </select>
                        </div>
            </div>
 
 
            <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Retreté(e)*</strong></label>
  <input className="text-label" type="checkbox" id="scales" name="scales"
         />
            </div>
            </div>
 
 
            <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Type d'âge *</strong></label>
                                    <select
                                      className="form-control"
                                      id="inputState"
                                      defaultValue="option-1"
                                    >
                                      <option value="option-1">Enfants (entre 00 à 14 ans )</option>
                                      <option value="option-2"> Adolescents (entre 15 à 24 ans ) </option>
                                      <option value="option-3">Adultes ( entre 25 à 64 ans)</option>
                                      <option value="option-3">Aînés (entre 65 ans et plus)</option>
 
                                     
                                    </select>
            </div>
            </div>
 
 
            <div class="row justify-content-around">
    <div class="col-3">
    <button className="btn btn-primary btn-block"  onClick={this.nextp2}>précédent
    
    </button>  


</div>
    <div class="col-3">
    <button className="btn btn-primary btn-block"  onClick={this.nextp3}>suivant</button>  
    </div>
  </div>


                              </form>
                              </div>
 
                        </div>
                     </div>
                  </div>
               </div>
               </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
        </div>

        <div style={this.state.p3P}>
        <div className="row">
      <div className="col-lg-12 mb-2">
         <div className="form-group">
         <div className="col-lg-12 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
           <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
           <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> 
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br></h1></div><br></br>
           <br></br>
           
      <div className="authincation h-100 p-meddle">
         <div className="container h-100">
            <div className="row justify-content-center h-100 align-items-center">
               <div className="col-md-8">
                  <div className="authincation-content">
                     <div className="row no-gutters">
                        <div className="col-xl-12">
                           <div className="auth-form">
                           <h6 className="text-center mb-4">
                               Etape 3/4
                              </h6>
                              <h2 className="text-center mb-4">
                              Antécédents
                              </h2><br></br> <br></br>
                              <form
                                 action=""
                                
                              >
                                <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label">  <strong>  Avez-vous des problèmes cardiaques </strong> </label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Avez-vous déjà fumé du tabac de quelque sorte?
Veuillez indiquer quel produit</strong></label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Avez-vous d’autres problèmes respiratoires? </strong> </label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Avez-vous déjà eu une maladie ou un trouble lié au sang? </strong></label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Avez-vous déjà eu des problèmes importants de mémoire ou de démence? </strong> </label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Est-ce que vous ou un membre de votre famille (lié à vous par le sang)
avez eu des problèmes graves autres que des nausées et vomissements
après avoir reçu une anesthésie générale </strong> </label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez"
                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong>Avez-vous été admis(e) à l’hôpital dans le passé? </strong></label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez ( Quand? Où? Pourquoi?)"                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"> <strong> Etes vous concerné par des problèmes de santé mentale (ex.
, crises d’angoisse, phobie des aiguilles)?</strong></label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez ( Quand? Où? Pourquoi?)"                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
                 <div className="row">
            <div className="col-lg-6 mb-2">
               <div className="form-group">
                  <label className="text-label"><strong> Y’a-t-il des problèmes d’allergie dans l’anamnèse personnelle ?</strong></label>
               
               </div>
            </div>
            <div className="col-lg-6 mb-2">
               <div className="form-group">
               <input type="radio" value="Male" name="gender" /> OUI
        <input type="radio" value="Female" name="gender"  /> NON
               </div>
            </div></div>
            <div className="col-lg-12 mb-2">
               <div className="form-group">
               <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     placeholder="présisez ( Quand? Où? Pourquoi?)"                     cols="20" rows="2"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
 
 
 
                 
                 <div class="row justify-content-around">
    <div class="col-3">
    <button className="btn btn-primary btn-block"  onClick={this.nextp3}>précédent</button>  


</div>
    <div class="col-3">
    <button className="btn btn-primary btn-block"  onClick={this.nextp4}>suivant</button>  
    </div>
  </div>
               

 
                              </form>
                              </div>
 
                        </div>
                     </div>
                  </div>
               </div>
               </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
        </div>

        <div style={this.state.p4P}>
        <section>
        <div className="row">
      <div className="col-lg-12 mb-2">
         <div className="form-group">
         <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
        </div><br></br>
           <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2">
           <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
             <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
        </div><br></br></div><br></br>
      <div className="authincation h-100 p-meddle">
         <div className="container h-100">
            <div className="row justify-content-center h-100 align-items-center">
               <div className="col-md-8">
                  <div className="authincation-content">
                     <div className="row no-gutters">
                        <div className="col-xl-12">
                           <div className="auth-form">
                           <h6 className="text-center mb-4">
                               Etape 4/4
                              </h6>
                              <h2 className="text-center mb-4">
                               Se connecter
                              </h2><br></br> <br></br>
                              <form
                               
                              >
                                <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label">
                                       <strong >Mot de passe</strong>
                                    </label>
                  <input
                     type="password"
                     className="form-control"
                     defaultValue="Password"
                     name="password"
                  />
               </div>
            </div>
         <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label">
                                       <strong >Confirmez le Mot de passe</strong>
                                    </label>
                  <input
                     type="password"
                     className="form-control"
                     defaultValue="Password"
                     name="password"
                  />
               </div>
            </div>
                              
                                


            <div class="row justify-content-end">
    <div class="col-4">
    <button className="btn btn-primary btn-block" onClick={this.nextp5} >Valider</button>  
    </div>
    <div class="col-4">
    </div>
  </div>


 
                              </form>
                              </div>
 
                        </div>
                     </div>
                  </div>
               </div>
               </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </section>
        </div>
        <div style={this.state.p2M}>
        <div className="row">
      <div className="col-lg-12 mb-2">
         <div className="form-group">
         <div className="col-lg-12 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
           <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
             
               <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br></h1></div><br></br>
           <br></br>
           
      <div className="authincation h-100 p-meddle">
         <div className="container h-100">
            <div className="row justify-content-center h-100 align-items-center">
               <div className="col-md-8">
                  <div className="authincation-content">
                     <div className="row no-gutters">
                        <div className="col-xl-12">
                           <div className="auth-form">
                           <h6 className="text-center mb-4">
                               Etape 2/4
                              </h6>
                              <h2 className="text-center mb-4">
                              Informations sur le professionel de santé
                              </h2>
                              <form
                                 action=""
                                 
                              >
                                <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"> <strong>Identifiant RPPS *</strong></label>
                  <input
                     type="Password"
                     name="place"
                     className="form-control"
                     placeholder="*********"
                     required
                  />
                  </div>
               
            </div>
            <div className="col-lg-12 mb-3">
            <div className="form-group">
               <label className="text-label"><strong> Numéro carte d'identité *</strong></label>
                  <input
                     type="Password"
                     name="place"
                     className="form-control"
                     placeholder="*********"
                     required
                  />
                  </div>
                  </div>
                  <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Joindrez votre carte CIN et votre Signature</strong></label></div>
   
 
    <input type="file"
           id="avatar" name="avatar"
           accept="image/png, image/jpeg"  className="form-control"/>
            </div>
               <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Type*</strong></label>
                                    <select
                                      className="form-control"
                                      id="inputState"
                                      defaultValue="option-1"
                                    >
                                      <option value="option-1">médecin</option>
                                      <option value="option-2">chirurgien  </option>
                                      <option value="option-3">Biologiste</option>
                                     
                        </select>
                        </div>
            </div>
            <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Spécialité*</strong></label>
                                    <select
                                      className="form-control"
                                      id="inputState"
                                      defaultValue="option-1"
                                    >
                                      <option value="option-1">Dermatologie</option>
                                      <option value="option-2">Pédiatrie  </option>
                                      <option value="option-3">Psychiatrie</option>
                                      <option value="option-3">Pédopsychiatrie</option>
                                      <option value="option-3">Cardiologie</option>
                                      <option value="option-3">Néphrologie</option>
                                      <option value="option-3">Neurologie</option>
                                      <option value="option-3">Pneumologie</option>
                                      <option value="option-3">Rhumatologie</option>
                                      <option value="option-3">Gastro-entérologie</option>
                                      <option value="option-3"> généraliste</option>
                                      <option value="option-3"> Ophtalmologie</option>
                                      <option value="option-3"> généraliste</option>
                                      <option value="option-3"> Gynécologie</option>
                                      <option value="option-3"> O.R.L</option>
                                      <option value="option-3"> Anesthésie</option>
                                     
                        </select>
                        </div>
            </div>
            <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Adresse E-mail professionel*</strong></label></div>
   
 
            <input
                     type="email"
                     name="place"
                     className="form-control"
                     placeholder="example@gmail.com"
                     required
                  />
            </div>

            <div className="col-lg-12 mb-3"> 
               
               <label className="text-label"><strong>Langue parlé*</strong></label></div>
              

            <div className="col-lg-12 mb-3">
               <div className="form-group">
                 
               <label className="text-label">Arabe</label>
              
  <input className="text-label" type="checkbox" id="scales" name="scales"
         />
                      <label className="text-label">Français</label>
              
              <input className="text-label" type="checkbox" id="scales" name="scales"
                     />
                                  <label className="text-label">Anglais</label>
              
              <input className="text-label" type="checkbox" id="scales" name="scales"
                     />
            </div>
            </div>
 
            <div className="col-lg-12 mb-2">
               <div className="form-group">
                  <label className="text-label">
Expérience                   </label>
                  <textarea
                     name="paragraph_text"
                     type="text"
                     name="place"
                     className="form-control"
                     cols="50" rows="10"
                     required
                  >
                 </textarea>
                 </div>
                 </div>
 
                 <div class="row justify-content-around">
    <div class="col-3">
    <button className="btn btn-primary btn-block"  onClick={this.nextp2}>précédent</button>  


</div>
    <div class="col-3">
    <button className="btn btn-primary btn-block"  onClick={this.nextp3}>suivant</button>  
    </div>
  </div>
 
                              </form>
                              </div>
 
                        </div>
                     </div>
                  </div>
               </div>
               </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
         
        </div>

        <div style={this.state.p3M}>
        <div className="row">
      <div className="col-lg-12 mb-2">
         <div className="form-group">
         <div className="col-lg-12 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
           <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2"><div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>    <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           <h1></h1></div><br></br></h1></div><br></br>
           <br></br>
           
      <div className="authincation h-100 p-meddle">
         <div className="container h-100">
            <div className="row justify-content-center h-100 align-items-center">
               <div className="col-md-8">
                  <div className="authincation-content">
                     <div className="row no-gutters">
                        <div className="col-xl-12">
                           <div className="auth-form">
                           <h6 className="text-center mb-4">
                               Etape 3/4
                              </h6>
                              <h2 className="text-center mb-4">
                              Informations sur l'établissement
                              </h2>
                              <form
                                 action=""
                                
                              >
                                <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"> <strong>Nom de l'établissement * *</strong></label>
                  <input
                     type="Password"
                     name="place"
                     className="form-control"
                     placeholder=""
                     required
                  />
                  </div>
               
            </div>
            <div className="col-lg-12 mb-3">
            <div className="form-group">
               <label className="text-label"><strong> Numéro de l'établissement *</strong></label>
                  <input
                     type="Password"
                     name="place"
                     className="form-control"
                     placeholder=""
                     required
                  />
                  </div>
                  </div>
              

                  <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Adresse de l'établissement *</strong></label>
               <input
                     type="Password"
                     name="place"
                     className="form-control"
                     placeholder=""
                     required
                  />
               </div>
               </div>
   
 
    
              
            <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Ville*</strong></label>
                                    <select
                                      className="form-control"
                                      id="inputState"
                                      defaultValue="option-1"
                                    >
                                      	
												  <option value="option-1">Ariana</option>
												  <option value="option-2">Beja </option>
												  <option value="option-3">Ben Arous</option>
												  <option value="option-4">Bizerte</option>
                                      <option value="option-5">Gabes</option>
                                      <option value="option-6">Gafsa</option>
                                      <option value="option-7">Jendouba</option>
                                      <option value="option-8">Kairouan</option>
                                      <option value="option-9">Kasserine</option>
                                      <option value="option-10">kebili</option>
                                      <option value="option-11">La Manouba</option>
                                      <option value="option-12">Kef</option>
                                      <option value="option-13">Mahdia</option>
                                      <option value="option-14">Médenine</option>
                                      <option value="option-15">Monastir</option>
                                      <option value="option-16">Nabeul</option>
                                      <option value="option-17">Sfax</option>
                                      <option value="option-18">Sidi Bouzid</option>
                                      <option value="option-19">Siliana</option>
                                      <option value="option-20">Sousse</option>
                                      <option value="option-21">Tataouine</option>
                                      <option value="option-22">Tozeur</option>
                                      <option value="option-23">Tunis</option>
                                      <option value="option-24">zaghouan</option>
                                     
                        </select>
                        </div>
            </div>
            <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Adresse E-mail de l'établissement*</strong></label></div>
   
 
            <input
                     type="email"
                     name="place"
                     className="form-control"
                     placeholder="example@gmail.com"
                     required
                  />
            </div>
            <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Site web*</strong></label></div>
   
 
            <input
                     type="email"
                     name="place"
                     className="form-control"
                     placeholder="example@gmail.com"
                     required
                  />
            </div>
           
            <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Heure début de journée  *</strong></label>
                  <input
                     type="number"
                     name="place"
                     className="form-control"
                     placeholder="9H"
                     required
                  />
            </div>
            </div>
            <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label"><strong>Heure fin de journée *</strong></label>
                  <input
                     type="number"
                     name="place"
                     className="form-control"
                     placeholder="18H"
                     required
                  />
            </div>
            </div>
 
            <div class="row justify-content-around">
    <div class="col-3">
    <button className="btn btn-primary btn-block"  onClick={this.nextp3}>précédent</button>  


</div>
    <div class="col-3">
    <button className="btn btn-primary btn-block"  onClick={this.nextp4}>suivant</button>  
    </div>
  </div>
 
                              </form>
                              </div>
 
                        </div>
                     </div>
                  </div>
               </div>
               </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
        </div>

        <div style={this.state.p4M}>
        <section>
        <div className="row">
      <div className="col-lg-12 mb-2">
         <div className="form-group">
         <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
        </div><br></br>
           <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2">
           <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2"> <div className="form-group"></div>
           </div><br></br>   <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
             <div className="col-lg-8 mb-2">
               <div className="form-group"></div>
        </div><br></br></div><br></br>
      <div className="authincation h-100 p-meddle">
         <div className="container h-100">
            <div className="row justify-content-center h-100 align-items-center">
               <div className="col-md-8">
                  <div className="authincation-content">
                     <div className="row no-gutters">
                        <div className="col-xl-12">
                           <div className="auth-form">
                           <h6 className="text-center mb-4">
                               Etape 4/4
                              </h6>
                              <h2 className="text-center mb-4">
                               Se connecter
                              </h2><br></br> <br></br>
                              <form
                               
                              >
                                <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label">
                                       <strong >Mot de passe</strong>
                                    </label>
                  <input
                     type="password"
                     className="form-control"
                     defaultValue="Password"
                     name="password"
                  />
               </div>
            </div>
         <div className="col-lg-12 mb-3">
               <div className="form-group">
               <label className="text-label">
                                       <strong >Confirmez le Mot de passe</strong>
                                    </label>
                  <input
                     type="password"
                     className="form-control"
                     defaultValue="Password"
                     name="password"
                  />
               </div>
            </div>
                              
                                


            <div class="row justify-content-end">
    <div class="col-4">
    <div className="sweetalert mt-5">
    <button
                              onClick={() =>
                                 swal(
                                    "Formulaire rempli avec succés ",
                                    "Merci de remplir le formulaire",
                                    "success"
                                 )
                              }
                            
                            className="btn btn-success btn sweet-success"
                         >
                            Valider
                         </button>
                         
   </div>
                        
    </div>
    <div class="col-4">
    </div>
  </div>


 
                              </form>

                              
                              </div>
 
                        </div>
                     </div>
                  </div>
               </div>
               </div>
                  </div>
               </div>
            </div>
         </div>
      </div>

      </section>
        </div>
      </>

    );
  }

}
export default App;

